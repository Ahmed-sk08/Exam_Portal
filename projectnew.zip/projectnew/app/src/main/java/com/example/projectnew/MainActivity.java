package com.example.projectnew;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Hardcoded student IDs and passwords (in a real application, you should use secure authentication)
    private static final String[] studentIDs = {"123", "456", "789", "101", "202"};
    private static final String[] passwords = {"pass123", "pass456", "pass789", "pass101", "pass202"};

    private EditText idNumberEditText;
    private EditText passwordEditText;
    private Button loginButton;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        idNumberEditText = findViewById(R.id.idnumber);
        passwordEditText = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginbutton);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get entered ID and password
                String enteredID = idNumberEditText.getText().toString().trim();
                String enteredPassword = passwordEditText.getText().toString().trim();

                // Check if the entered credentials are valid
                if (isValidCredentials(enteredID, enteredPassword)) {
                    // Successful login
                    Toast.makeText(MainActivity.this, "Successfully logged in", Toast.LENGTH_SHORT).show();

                    // Start the Fees activity
                    Intent intent = new Intent(MainActivity.this, Fees.class);
                    startActivity(intent);
                } else {
                    // Invalid credentials
                    Toast.makeText(MainActivity.this, "Invalid credentials. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Check if entered credentials are valid
    private boolean isValidCredentials(String enteredID, String enteredPassword) {
        for (int i = 0; i < studentIDs.length; i++) {
            if (enteredID.equals(studentIDs[i]) && enteredPassword.equals(passwords[i])) {
                return true; // Valid credentials
            }
        }
        return false; // Invalid credentials
    }
}
