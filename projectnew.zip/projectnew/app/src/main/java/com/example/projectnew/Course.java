package com.example.projectnew;

public class Course {
    private String firstCourse;
    private String secondCourse;
    private String thirdCourse;
    private String fourthCourse;
    private String fifthCourse;

    // Empty constructor required by Firebase
    public Course() {
    }

    public Course(String firstCourse, String secondCourse, String thirdCourse, String fourthCourse, String fifthCourse) {
        this.firstCourse = firstCourse;
        this.secondCourse = secondCourse;
        this.thirdCourse = thirdCourse;
        this.fourthCourse = fourthCourse;
        this.fifthCourse = fifthCourse;
    }

    public String getFirstCourse() {
        return firstCourse;
    }

    public void setFirstCourse(String firstCourse) {
        this.firstCourse = firstCourse;
    }

    public String getSecondCourse() {
        return secondCourse;
    }

    public void setSecondCourse(String secondCourse) {
        this.secondCourse = secondCourse;
    }

    public String getThirdCourse() {
        return thirdCourse;
    }

    public void setThirdCourse(String thirdCourse) {
        this.thirdCourse = thirdCourse;
    }

    public String getFourthCourse() {
        return fourthCourse;
    }

    public void setFourthCourse(String fourthCourse) {
        this.fourthCourse = fourthCourse;
    }

    public String getFifthCourse() {
        return fifthCourse;
    }

    public void setFifthCourse(String fifthCourse) {
        this.fifthCourse = fifthCourse;
    }
}
