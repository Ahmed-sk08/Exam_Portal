package com.example.projectnew;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class Fees extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.feesfirst); // Set the content view to feesfirst.xml
    }

    public void onAddCourseButtonClick(View view) {
        // Open the feesadd activity when the "ADD COURSE" button is clicked
        Intent intent = new Intent(this, feesadd.class);
        startActivity(intent);
    }

    public void onViewGradesButtonClick(View view) {
        // Open the feesadd activity when the "VIEW GRADES" button is clicked
        Intent intent = new Intent(this, feesview.class);
        startActivity(intent);
    }
}
