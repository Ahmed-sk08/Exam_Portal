package com.example.projectnew;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;



public class feesadd extends AppCompatActivity {

    private EditText firstEditText, secondEditText, thirdEditText, fourthEditText, fifthEditText;
    private Button btnInsert;

    // Firebase
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_fees);

        // Initialize Firebase
        databaseReference = FirebaseDatabase.getInstance().getReference().child("courses");

        // Initialize UI elements
        firstEditText = findViewById(R.id.first);
        secondEditText = findViewById(R.id.second);
        thirdEditText = findViewById(R.id.third);
        fourthEditText = findViewById(R.id.fourth);
        fifthEditText = findViewById(R.id.fifth);
        btnInsert = findViewById(R.id.btnInsert);

        // Set a click listener for the button
        btnInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                insertDataIntoFirebase();
            }
        });
    }

    private void insertDataIntoFirebase() {
        // Get values from EditText fields
        String firstCourse = firstEditText.getText().toString();
        String secondCourse = secondEditText.getText().toString();
        String thirdCourse = thirdEditText.getText().toString();
        String fourthCourse = fourthEditText.getText().toString();
        String fifthCourse = fifthEditText.getText().toString();

        // Create a new Courses object (you can create a custom class for this)
        Course courses = new Course(firstCourse, secondCourse, thirdCourse, fourthCourse, fifthCourse);

        // Push the data to Firebase
        databaseReference.push().setValue(courses)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            // Data insertion successful
                            showSuccessMessage();
                        } else {
                            // Data insertion failed
                            // Handle the error
                        }
                    }
                });
    }
    private void showSuccessMessage() {
        // Display a Toast message
        Toast.makeText(feesadd.this, "Successfully added the courses", Toast.LENGTH_SHORT).show();
    }
}
